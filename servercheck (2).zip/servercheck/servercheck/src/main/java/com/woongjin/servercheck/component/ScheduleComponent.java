package com.woongjin.servercheck.component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.Date;
import java.util.Map;

@Component
public class ScheduleComponent {

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final String SMS_API_URL = "https://wsms.woongjin.com/wjApi/sms/sendMsgApi";
    private static final String SMS_API_KEY = "g/qXB0c5/+g9OASU8Azxe682Wbu1bgKXljPKHLbCRwA=";
    private static final String[] RECIPIENTS = {"01047113052", "01044075269"}; // 공통 수신자 번호

    /**
     * SMS 발송 공통 함수
     */
    private void sendSms(String message) {
        try {
            String boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW";

            // JSON 메시지
            String innerJson = "{"
                    + "\"DSPTH_TNO\": \"" + RECIPIENTS[0] + "\"," // 대표 발송 번호
                    + "\"MSG_CN\": \"" + message + "\","
                    + "\"SNDG_ID\": \"Admin\","
                    + "\"MSG_GB\": \"SMS\","
                    + "\"RSRVT_DTTM\": \"\","
                    + "\"RSRVT_WD\": \"\","
                    + "\"RSRVT_YN\": \"N\","
                    + "\"ETC1\": \"\","
                    + "\"ETC2\": \"\","
                    + "\"ETC3\": \"\","
                    + "\"ETC4\": \"\","
                    + "\"ETC5\": \"\","
                    + "\"ETC6\": \"\","
                    + "\"RCP_TNO_LIST\": [\"" + String.join("\",\"", RECIPIENTS) + "\"]"
                    + "}";

            URL url = new URL(SMS_API_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("Authorization", SMS_API_KEY);
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream();
                 PrintWriter writer = new PrintWriter(new OutputStreamWriter(os, StandardCharsets.UTF_8), true)) {

                writer.append("--").append(boundary).append("\r\n");
                writer.append("Content-Disposition: form-data; name=\"DATA\"\r\n");
                writer.append("Content-Type: application/json; charset=UTF-8\r\n\r\n");
                writer.append(innerJson).append("\r\n");
                writer.append("--").append(boundary).append("--").append("\r\n");
                writer.flush();
            }

            int responseCode = conn.getResponseCode();

        } catch (Exception e) {
        }
    }

    /**
     * 서버 API 체크
     */
    @Scheduled(cron = "0 */10 * * * *")
    public void execServerCheck() {
        try {
            HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
            factory.setConnectTimeout(5000);
            factory.setReadTimeout(10000);

            // https://wkko.woongjin.com/kko/ntlk/sndg
            RestTemplate checkRestTemplate = new RestTemplate(factory);
            ResponseEntity<String> kkoResponse = checkRestTemplate.getForEntity(
                    "https://wkko.woongjin.com/kko/ntlk/sndg", String.class);
            String context = kkoResponse.getBody();

            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> resultMap = objectMapper.readValue(context, new TypeReference<Map<String, Object>>() {});

            String checkValue = resultMap.get("resultCode").toString();

            if (!"E001".equals(checkValue)) {
                sendSms(" 알림톡 API 오류 발생 (resultCode: " + checkValue + ")");
            }

        } catch (Exception e) {
            sendSms(" == 알림톡 API 호출 실패 == ");
        }
    }

    /**
     * SSL 인증서 체크 오전 9시마다 체크
     */
    @Scheduled(cron = "0 0 9 * * *")
    public void execSSLCheck() {
        try {
            //
            //"https://wkko-internal.woongjin.com/kko/ntlk/sndg";
            String targetUrl = "https://wkko.woongjin.com/kko/ntlk/sndg";
            URL url = new URL(targetUrl);
            HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
            conn.connect();

            Certificate[] certs = conn.getServerCertificates();
            for (Certificate cert : certs) {
                if (cert instanceof X509Certificate) {
                    X509Certificate x509Cert = (X509Certificate) cert;

                    Date now = new Date();
                    Date expiry = x509Cert.getNotAfter();
                    long diffMs = expiry.getTime() - now.getTime();
                    long diffDays = diffMs / (1000 * 60 * 60 * 24);

                    if (diffDays < 0) {
                        sendSms(" [" + targetUrl + "] SSL 인증서가 만료되었습니다!");
                    } else if (diffDays <= 30) {
                        sendSms(" [" + targetUrl + "] SSL 인증서 만료 임박 (" + diffDays + "일 남음)");
                    }
                }
            }

        } catch (Exception e) {
            sendSms(" SSL 인증서 확인 실패: " + e.getMessage());
        }
    }
}